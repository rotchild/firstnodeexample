Ext.define('UserCenterSystem.view.NorthPanel', {
    extend: 'Ext.Panel',
    xtype: 'northPanel',//alias : 'widget.northPanel',等价
    border: false,
    height: 58,
    layout: 'border',
 bodyStyle: {
        backgroundImage: 'url(../images/banner-2000x581.png)',
        backgroundColor: '#000000',
        margin: 0,
        padding: 0
    },
    html: '<div style="display: inline-block;"><img style="height: 100%;padding-left: 20px;padding-top: 8px" src="../images/managesystem.png" /></div>' +
    '<div style="display: inline-block;float: right;text-align: center;color:#ffffff;font-weight:bold " id="divUserInfo"></div>' +
    '<div style="display: inline-block;float: right;text-align: center;color:#ffffff;font-weight:bold " id="divUserInfo"></div>'

});